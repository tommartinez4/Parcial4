﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Articulo.Models
{
    public class calculo
    {
        public int cantidad { get; set; }
        public double precio { get; set; }
        public double desc { get; set; }
    }
}