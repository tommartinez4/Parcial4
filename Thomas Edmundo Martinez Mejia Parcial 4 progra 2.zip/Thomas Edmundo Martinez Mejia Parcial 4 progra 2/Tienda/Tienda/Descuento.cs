﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tienda
{
    delegate double Total(double Z);
    class Descuento
    {
        public double descuento(double Z){ 
        double resultado = 0;
            if (Z > 10000 & Z< 20000)
            {
                resultado = Z* 0.10;

            }
            if (Z > 20001 & Z< 50000)
            {
                    resultado = Z* 0.30;

            }
            if (Z > 50000)
            {
                resultado = Z* 0.50;

            }
            return resultado ;
        }
    }
}
