﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tienda
{
    class Program
    {
        static void Main(string[] args)
        {
            
        
                Descuento dlg = new Descuento();
                string respuesta;
                double Total, acum = 0, Totaldescuento;
                Console.WriteLine("ELCOME TO WALMART PRESS (YES) TO CONTINUE ");
                respuesta = Console.ReadLine().ToUpper();
                Console.WriteLine("----------------------------------------------------------");
                while (respuesta == "YES")
                {

                    Console.WriteLine("INGRESE EL PRECIO DEL PRODUCTO ");
                    Total = Convert.ToDouble(Console.ReadLine());
                    acum = acum + Total;
                    Console.WriteLine("DESEA INGRESAR MAS PRODUCTOS?(INGRESE NO PARA SALIR/YES TO CONTINUE ) ");
                    respuesta = Console.ReadLine().ToUpper();
                }
                Total delegadodesc = dlg.descuento;
                Console.WriteLine("DESCUENTO REALIZADO ES: $" + delegadodesc(acum));
                Totaldescuento = acum - delegadodesc(acum);
                Console.WriteLine("SU DESCUENTO APLICADO ES: $" + Totaldescuento);
                Console.ReadKey();
            
        }
    }
}
