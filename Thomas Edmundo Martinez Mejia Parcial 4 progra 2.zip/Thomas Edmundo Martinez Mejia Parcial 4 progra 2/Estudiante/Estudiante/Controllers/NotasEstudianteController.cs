﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Estudiante.Models;

namespace Estudiante.Controllers
{
    public class NotasEstudianteController : Controller
    {
        // GET: NotasEstudiante
        public ActionResult Notas()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Notas(calculo obCalculo)
        {
            double resultado = (obCalculo.nota1 + obCalculo.nota2 + obCalculo.nota3) / 3;
            if (resultado > 4 & resultado < 10)
            {
                ViewBag.resultado = resultado + " Aprobado";
            }
            else if (resultado <= 4)
            {
                ViewBag.resultado = resultado + " Reprobado ";
            }
            else
                ViewBag.resultado = resultado;
            return View(obCalculo);
        }
    }
}