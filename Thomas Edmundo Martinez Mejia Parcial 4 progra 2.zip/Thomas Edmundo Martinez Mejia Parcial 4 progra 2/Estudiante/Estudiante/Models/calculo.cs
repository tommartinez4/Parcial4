﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Estudiante.Models
{
    public class calculo
    {
        public string carnet { get; set; }
        public string nombre { get; set; }
        public string materia { get; set; }
        public double nota1 { get; set; }
        public double nota2 { get; set; }
        public double nota3 { get; set; }
    }
}